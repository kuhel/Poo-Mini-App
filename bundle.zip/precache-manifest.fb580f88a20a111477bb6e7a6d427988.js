self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "61b37135b2ec11cfc2b01ae8ab457c66",
    "url": "/index.html"
  },
  {
    "revision": "90cc01d176ad9859cf59",
    "url": "/static/css/2.b09f2111.chunk.css"
  },
  {
    "revision": "932a994b1cc57d14095e",
    "url": "/static/css/main.e5b60844.chunk.css"
  },
  {
    "revision": "90cc01d176ad9859cf59",
    "url": "/static/js/2.39bbc718.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.39bbc718.chunk.js.LICENSE.txt"
  },
  {
    "revision": "932a994b1cc57d14095e",
    "url": "/static/js/main.1133b5d7.chunk.js"
  },
  {
    "revision": "59a0c35199c1e0119b03",
    "url": "/static/js/runtime-main.55cf02ba.js"
  },
  {
    "revision": "b528eaf852da05eb9fbb826b13d854d5",
    "url": "/static/media/roll.b528eaf8.svg"
  }
]);