self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9aef0c20d2857cd756b0dcab64b925f6",
    "url": "/index.html"
  },
  {
    "revision": "90cc01d176ad9859cf59",
    "url": "/static/css/2.b09f2111.chunk.css"
  },
  {
    "revision": "934cf8d95deddd9c6250",
    "url": "/static/css/main.e5b60844.chunk.css"
  },
  {
    "revision": "90cc01d176ad9859cf59",
    "url": "/static/js/2.39bbc718.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.39bbc718.chunk.js.LICENSE.txt"
  },
  {
    "revision": "934cf8d95deddd9c6250",
    "url": "/static/js/main.d1aebe53.chunk.js"
  },
  {
    "revision": "59a0c35199c1e0119b03",
    "url": "/static/js/runtime-main.55cf02ba.js"
  },
  {
    "revision": "b528eaf852da05eb9fbb826b13d854d5",
    "url": "/static/media/roll.b528eaf8.svg"
  }
]);