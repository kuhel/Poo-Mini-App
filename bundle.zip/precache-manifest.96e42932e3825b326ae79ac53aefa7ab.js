self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d930d9c33ec322e14d6f6660cb0a7c32",
    "url": "/index.html"
  },
  {
    "revision": "90cc01d176ad9859cf59",
    "url": "/static/css/2.b09f2111.chunk.css"
  },
  {
    "revision": "15f2712dc59326adf181",
    "url": "/static/css/main.96188041.chunk.css"
  },
  {
    "revision": "90cc01d176ad9859cf59",
    "url": "/static/js/2.39bbc718.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.39bbc718.chunk.js.LICENSE.txt"
  },
  {
    "revision": "15f2712dc59326adf181",
    "url": "/static/js/main.90a0e0a3.chunk.js"
  },
  {
    "revision": "59a0c35199c1e0119b03",
    "url": "/static/js/runtime-main.55cf02ba.js"
  },
  {
    "revision": "b528eaf852da05eb9fbb826b13d854d5",
    "url": "/static/media/roll.b528eaf8.svg"
  }
]);